//
//  IScribeAISource.h
//  IScribeAISource
//
//  Created by Bobby Rehm on 9/23/24.
//

#import <Foundation/Foundation.h>

//! Project version number for IScribeAISource.
FOUNDATION_EXPORT double IScribeAISourceVersionNumber;

//! Project version string for IScribeAISource.
FOUNDATION_EXPORT const unsigned char IScribeAISourceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IScribeAISource/PublicHeader.h>


